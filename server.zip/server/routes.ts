import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import axios from "axios";

async function fetchYoutubeVideos(apiKey: string) {
  try {
    console.log("Fetching YouTube videos with API key:", apiKey.substring(0, 5) + "...");
    const response = await axios.get("https://www.googleapis.com/youtube/v3/videos", {
      params: {
        key: apiKey,
        part: "snippet,contentDetails,statistics",
        chart: "mostPopular",
        maxResults: 24,
        regionCode: "US"
      }
    });

    const items = response.data.items;
    console.log(`Found ${items?.length || 0} popular videos from YouTube`);
    
    if (!items || items.length === 0) {
      console.log("No videos found in YouTube response:", JSON.stringify(response.data));
      return;
    }

    for (const item of items) {
      if (!item.id) continue;
      
      const snippet = item.snippet;
      const statistics = item.statistics;
      
      await storage.upsertVideo({
        youtubeId: item.id,
        title: snippet.title,
        description: snippet.description || "",
        thumbnailUrl: snippet.thumbnails.high?.url || snippet.thumbnails.medium?.url || "",
        channelName: snippet.channelTitle,
        channelId: snippet.channelId,
        channelAvatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(snippet.channelTitle)}`,
        duration: item.contentDetails?.duration || "PT10M0S",
        views: statistics?.viewCount ? parseInt(statistics.viewCount) : 0,
        publishedAt: snippet.publishedAt ? new Date(snippet.publishedAt) : new Date(),
      } as any);
    }
  } catch (error: any) {
    console.error("Error fetching YouTube videos:", error.response?.data || error.message);
  }
}

async function seedDatabase() {
  const existingVideos = await storage.getVideos();
  // We consider mock videos as those with no youtubeId or specific mock titles
  const hasMockVideos = existingVideos.some(v => !v.youtubeId);
  
  if (existingVideos.length === 0 || hasMockVideos) {
    const apiKey = process.env.YOUTUBE_API_KEY;
    if (apiKey) {
      await fetchYoutubeVideos(apiKey);
    }
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  await setupAuth(app);
  registerAuthRoutes(app);
  
  await seedDatabase();
  
  app.get(api.videos.list.path, async (req, res) => {
    try {
      const search = req.query.search as string | undefined;
      const apiKey = process.env.YOUTUBE_API_KEY;

      if (search && apiKey) {
        // Check if search is a YouTube URL
        const videoIdMatch = search.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([^&?]{11})/);
        
        if (videoIdMatch) {
          const videoId = videoIdMatch[1];
          const response = await axios.get("https://www.googleapis.com/youtube/v3/videos", {
            params: {
              key: apiKey,
              part: "snippet,contentDetails,statistics",
              id: videoId
            }
          });
          
          if (response.data.items?.length > 0) {
            const item = response.data.items[0];
            const video = await storage.upsertVideo({
              youtubeId: item.id,
              title: item.snippet.title,
              description: item.snippet.description || "",
              thumbnailUrl: item.snippet.thumbnails.high?.url || item.snippet.thumbnails.medium?.url || "",
              channelName: item.snippet.channelTitle,
              channelId: item.snippet.channelId,
              channelAvatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(item.snippet.channelTitle)}`,
              duration: item.contentDetails?.duration || "PT10M0S",
              views: item.statistics?.viewCount ? parseInt(item.statistics.viewCount) : 0,
              publishedAt: new Date(item.snippet.publishedAt),
            } as any);
            return res.json([video]);
          }
        }

        // Fetch from YouTube directly for search
        const response = await axios.get("https://www.googleapis.com/youtube/v3/search", {
          params: {
            key: apiKey,
            part: "snippet",
            q: search,
            type: "video",
            maxResults: 24,
            regionCode: "US"
          }
        });

        const items = response.data.items;
        const searchVideos = [];

      for (const item of items) {
        if (!item.id?.videoId) continue;
        
        // Fetch detailed info to get duration and statistics
        const detailResponse = await axios.get("https://www.googleapis.com/youtube/v3/videos", {
          params: {
            key: apiKey,
            part: "snippet,contentDetails,statistics",
            id: item.id.videoId
          }
        });

        const detailItem = detailResponse.data.items?.[0];
        
        const video = await storage.upsertVideo({
          youtubeId: item.id.videoId,
          title: item.snippet.title,
          description: item.snippet.description || "",
          thumbnailUrl: item.snippet.thumbnails.high?.url || item.snippet.thumbnails.medium?.url || "",
          channelName: item.snippet.channelTitle,
          channelId: item.snippet.channelId,
          channelAvatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(item.snippet.channelTitle)}`,
          duration: detailItem?.contentDetails?.duration || "PT10M0S",
          views: detailItem?.statistics?.viewCount ? parseInt(detailItem.statistics.viewCount) : 0,
          publishedAt: detailItem?.snippet?.publishedAt ? new Date(detailItem.snippet.publishedAt) : (item.snippet.publishedAt ? new Date(item.snippet.publishedAt) : new Date()),
        } as any);
        searchVideos.push(video);
      }
        return res.json(searchVideos);
      }

      const videos = await storage.getVideos(search);
      res.json(videos);
    } catch (err) {
      console.error("Error in GET /api/videos:", err);
      res.status(500).json({ message: "Failed to fetch videos" });
    }
  });

  app.get(api.videos.get.path, async (req, res) => {
    try {
      const videoId = Number(req.params.id);
      const video = await storage.getVideo(videoId);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }

      // Add to history if user is signed in
      const user = req.user as any;
      if (user?.id) {
        await storage.addToHistory(user.id, videoId);
      }

      res.json(video);
    } catch (err) {
      console.error("Error in GET /api/videos/:id:", err);
      res.status(500).json({ message: "Failed to fetch video" });
    }
  });

  app.get("/api/history", async (req, res) => {
    try {
      const user = req.user as any;
      if (!user?.id) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      const history = await storage.getHistory(user.id);
      res.json(history || []);
    } catch (err) {
      console.error("Error in GET /api/history:", err);
      res.status(500).json({ message: "Failed to fetch history" });
    }
  });

  app.get("/api/channels/:channelId/videos", async (req, res) => {
    try {
      const apiKey = process.env.YOUTUBE_API_KEY;
      if (!apiKey) return res.status(500).json({ message: "YouTube API key missing" });

      const response = await axios.get("https://www.googleapis.com/youtube/v3/search", {
        params: {
          key: apiKey,
          part: "snippet",
          channelId: req.params.channelId,
          type: "video",
          order: "date",
          maxResults: 50
        }
      });

      const items = response.data.items;
      const channelVideos = [];

      for (const item of items) {
        if (!item.id?.videoId) continue;
        
        // Fetch detailed info to get duration and statistics
        const detailResponse = await axios.get("https://www.googleapis.com/youtube/v3/videos", {
          params: {
            key: apiKey,
            part: "snippet,contentDetails,statistics",
            id: item.id.videoId
          }
        });

        const detailItem = detailResponse.data.items?.[0];
        
        const video = await storage.upsertVideo({
          youtubeId: item.id.videoId,
          title: item.snippet.title,
          description: item.snippet.description || "",
          thumbnailUrl: item.snippet.thumbnails.high?.url || item.snippet.thumbnails.medium?.url || "",
          channelName: item.snippet.channelTitle,
          channelId: item.snippet.channelId,
          channelAvatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(item.snippet.channelTitle)}`,
          duration: detailItem?.contentDetails?.duration || "PT10M0S",
          views: detailItem?.statistics?.viewCount ? parseInt(detailItem.statistics.viewCount) : 0,
          publishedAt: detailItem?.snippet?.publishedAt ? new Date(detailItem.snippet.publishedAt) : (item.snippet.publishedAt ? new Date(item.snippet.publishedAt) : new Date()),
        } as any);
        channelVideos.push(video);
      }
      res.json(channelVideos);
    } catch (err) {
      console.error("Error in GET /api/channels/:id/videos:", err);
      res.status(500).json({ message: "Failed to fetch channel videos" });
    }
  });

  app.get(api.comments.list.path, async (req, res) => {
    try {
      const videoId = Number(req.params.videoId);
      const video = await storage.getVideo(videoId);
      const apiKey = process.env.YOUTUBE_API_KEY;

      if (video?.youtubeId && apiKey) {
        // Fetch comments from YouTube API
        const response = await axios.get("https://www.googleapis.com/youtube/v3/commentThreads", {
          params: {
            key: apiKey,
            part: "snippet",
            videoId: video.youtubeId,
            maxResults: 20,
            textFormat: "plainText"
          }
        });

        const ytComments = response.data.items?.map((item: any) => ({
          id: item.id,
          videoId,
          username: item.snippet.topLevelComment.snippet.authorDisplayName,
          avatar: item.snippet.topLevelComment.snippet.authorProfileImageUrl,
          content: item.snippet.topLevelComment.snippet.textDisplay,
          likes: item.snippet.topLevelComment.snippet.likeCount,
          createdAt: item.snippet.topLevelComment.snippet.publishedAt
        })) || [];

        // Combine with local comments
        const localComments = await storage.getComments(videoId);
        return res.json([...ytComments, ...localComments]);
      }

      const comments = await storage.getComments(videoId);
      res.json(comments);
    } catch (err) {
      console.error("Error in GET /api/comments:", err);
      // Fallback to local comments on error
      const comments = await storage.getComments(Number(req.params.videoId));
      res.json(comments);
    }
  });

  app.post(api.comments.create.path, async (req, res) => {
    try {
      const input = api.comments.create.input.parse(req.body);
      const user = req.headers["x-replit-user-name"];
      const avatar = req.headers["x-replit-user-profile-image"];
      
      const comment = await storage.createComment({
        videoId: input.videoId,
        content: input.content,
        username: (user as string) || "Anonymous",
        avatar: (avatar as string) || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user || 'Anon'}`,
      });
      res.status(201).json(comment);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  return httpServer;
}
