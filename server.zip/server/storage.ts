import { db } from "./db";
import { videos, comments, videoHistory, type Video, type InsertVideo, type Comment, type InsertComment } from "@shared/schema";
import { eq, desc, like, sql } from "drizzle-orm";

export interface IStorage {
  getVideos(search?: string): Promise<Video[]>;
  getVideo(id: number): Promise<Video | undefined>;
  createVideo(video: InsertVideo): Promise<Video>;
  upsertVideo(video: InsertVideo & { channelId?: string; views?: number }): Promise<Video>;
  
  getComments(videoId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  
  addToHistory(userId: number, videoId: number): Promise<void>;
  getHistory(userId: number): Promise<Video[]>;
}

export class DatabaseStorage implements IStorage {
  async getVideos(search?: string): Promise<Video[]> {
    try {
      if (search) {
        return await db.select()
          .from(videos)
          .where(like(videos.title, `%${search}%`))
          .orderBy(desc(videos.publishedAt));
      }
      // Return videos in random order on each request
      return await db.select().from(videos).orderBy(sql`RANDOM()`);
    } catch (error) {
      console.error("Database error in getVideos:", error);
      return [];
    }
  }

  async getVideo(id: number): Promise<Video | undefined> {
    const [video] = await db.select().from(videos).where(eq(videos.id, id));
    return video;
  }

  async createVideo(video: InsertVideo): Promise<Video> {
    const [newVideo] = await db.insert(videos).values(video as any).returning();
    return newVideo;
  }

  async upsertVideo(videoData: InsertVideo & { channelId?: string; views?: number }): Promise<Video> {
    const [existing] = await db
      .select()
      .from(videos)
      .where(eq(videos.youtubeId, videoData.youtubeId));

    if (existing) {
      const [updated] = await db
        .update(videos)
        .set({
          ...videoData,
          views: videoData.views ?? existing.views,
        } as any)
        .where(eq(videos.id, existing.id))
        .returning();
      return updated;
    }

    const [inserted] = await db
      .insert(videos)
      .values(videoData as any)
      .returning();
    return inserted;
  }

  async getComments(videoId: number): Promise<Comment[]> {
    return await db.select()
      .from(comments)
      .where(eq(comments.videoId, videoId))
      .orderBy(desc(comments.createdAt));
  }

  async createComment(comment: InsertComment): Promise<Comment> {
    const [newComment] = await db.insert(comments).values(comment).returning();
    return newComment;
  }

  async addToHistory(userId: number, videoId: number): Promise<void> {
    await db.insert(videoHistory).values({ userId, videoId }).onConflictDoUpdate({
      target: [videoHistory.userId, videoHistory.videoId],
      set: { viewedAt: new Date() }
    });
  }

  async getHistory(userId: number): Promise<Video[]> {
    return await db.select({
      id: videos.id,
      youtubeId: videos.youtubeId,
      title: videos.title,
      description: videos.description,
      thumbnailUrl: videos.thumbnailUrl,
      channelName: videos.channelName,
      channelId: videos.channelId,
      channelAvatar: videos.channelAvatar,
      views: videos.views,
      duration: videos.duration,
      publishedAt: videos.publishedAt,
    })
      .from(videoHistory)
      .innerJoin(videos, eq(videoHistory.videoId, videos.id))
      .where(eq(videoHistory.userId, userId))
      .orderBy(desc(videoHistory.viewedAt));
  }
}

export const storage = new DatabaseStorage();
