## Packages
date-fns | Formatting dates relative to now (e.g., "2 hours ago")
clsx | Utility for conditional class names
tailwind-merge | Utility for merging tailwind classes safely
lucide-react | Icons for the UI

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Oswald", "sans-serif"],
}
