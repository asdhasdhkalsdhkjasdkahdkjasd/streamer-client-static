import { Search, Bell, MonitorPlay, LogOut } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { SiGoogle } from "react-icons/si";
import { useToast } from "@/hooks/use-toast";

export function Header() {
  const [location] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const { toast } = useToast();

  return (
    <div className="sticky top-0 z-40 bg-background/95 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-border/50">
      <Link href="/">
        <div className="flex items-center gap-1 cursor-pointer">
          <div className="bg-primary text-white p-1 rounded-lg">
            <MonitorPlay className="w-5 h-5 fill-current" />
          </div>
          <span className="font-display font-bold text-xl tracking-tight text-white">Streamer</span>
        </div>
      </Link>
      
      <div className="flex items-center gap-5">
        <Link href="/search">
          <Search className="w-6 h-6 text-white cursor-pointer hover:text-primary transition-colors" />
        </Link>
        <Bell className="w-6 h-6 text-white cursor-pointer hover:text-primary transition-colors hidden sm:block" />
        
        {isAuthenticated ? (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-8 w-8 rounded-full p-0">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user?.profileImageUrl || undefined} />
                  <AvatarFallback>{user?.firstName?.[0] || 'U'}</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuItem onClick={() => logout()}>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ) : (
          // When no user is authenticated, show a sign‑in button that displays a
          // toast instead of redirecting to a back‑end endpoint. This ensures
          // the static demo does not navigate to a missing server. The toast
          // informs users that sign‑in is unavailable in this offline build.
          <div
            className="flex items-center gap-2 px-3 h-9 rounded-full bg-white text-black text-sm font-semibold cursor-pointer hover:bg-white/90 transition-all"
            onClick={() =>
              toast({
                title: "Sign in unavailable",
                description: "This demo site does not support sign‑in.",
              })
            }
          >
            <SiGoogle className="w-4 h-4 text-[#4285F4]" />
            Sign in
          </div>
        )}
      </div>
    </div>
  );
}
