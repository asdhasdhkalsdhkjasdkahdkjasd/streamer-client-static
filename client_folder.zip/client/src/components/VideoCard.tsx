import { Link, useLocation } from "wouter";
import type { Video } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { MoreVertical } from "lucide-react";

interface VideoCardProps {
  video: Video;
  horizontal?: boolean;
}

// Function to parse ISO 8601 duration
function parseDuration(duration: string) {
  if (!duration || !duration.startsWith('PT')) return duration;
  const match = duration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!match) return duration;
  const h = match[1] ? parseInt(match[1]) : 0;
  const m = match[2] ? parseInt(match[2]) : 0;
  const s = match[3] ? parseInt(match[3]) : 0;
  
  if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

export function VideoCard({ video, horizontal = false }: VideoCardProps) {
  const [, setLocation] = useLocation();

  const handleChannelClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (video.channelId) {
      setLocation(`/channel/${video.channelId}`);
    }
  };

  const handleVideoClick = () => {
    setLocation(`/watch/${video.id}`);
  };

  const isShort = () => {
    // If the thumbnail is already vertical-ish, it's likely a short
    // But since we use thumbnailUrl from YouTube (usually 480x360 or similar), 
    // we should mainly rely on the title or duration.
    // However, the user says "any vertical video is a short".
    // Since I can't detect image aspect ratio easily here, I'll stick to a stricter duration check
    // or look for "#shorts" in the title.
    if (video.title.toLowerCase().includes("#shorts")) return true;
    
    if (!video.duration || !video.duration.startsWith('PT')) return false;
    const match = video.duration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
    if (!match) return false;
    const h = match[1] ? parseInt(match[1]) : 0;
    const m = match[2] ? parseInt(match[2]) : 0;
    const s = match[3] ? parseInt(match[3]) : 0;
    const totalSeconds = h * 3600 + m * 60 + s;
    return totalSeconds <= 60; // Usually shorts are 60s or less
  };

  if (isShort() && !horizontal) {
    return (
      <div 
        onClick={handleVideoClick}
        className="cursor-pointer group flex flex-col gap-2"
      >
        <div className="relative aspect-[9/16] rounded-xl overflow-hidden bg-muted">
          <img 
            src={video.thumbnailUrl} 
            alt={video.title}
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            loading="lazy"
          />
        </div>
        <div className="px-1">
          <h3 className="text-white text-sm font-medium leading-tight line-clamp-2 group-hover:text-primary transition-colors">
            {video.title}
          </h3>
          <p className="text-xs text-muted-foreground mt-1">
            {new Intl.NumberFormat('en-US', { notation: "compact" }).format(video.views || 0)} views
          </p>
        </div>
      </div>
    );
  }

  return (
    <div 
      onClick={handleVideoClick}
      className={`cursor-pointer group flex ${horizontal ? 'gap-2 mb-4' : 'flex-col gap-3 mb-6 sm:mb-8'}`}
    >
      {/* Thumbnail Container */}
      <div className={`relative aspect-video rounded-xl overflow-hidden bg-muted flex-shrink-0 ${horizontal ? 'w-40' : 'w-full'}`}>
        <div className="absolute inset-0 bg-neutral-800 animate-pulse" />
        <img 
          src={video.thumbnailUrl} 
          alt={video.title}
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute bottom-2 right-2 px-1.5 py-0.5 bg-black/80 backdrop-blur-sm rounded text-xs font-medium text-white">
          {parseDuration(video.duration)}
        </div>
      </div>

      {/* Info Area */}
      <div className="flex gap-3 px-1 sm:px-0 flex-1 min-w-0">
        {!horizontal && (
          <div onClick={handleChannelClick} className="flex-shrink-0">
            <img 
              src={video.channelAvatar} 
              alt={video.channelName}
              className="w-9 h-9 rounded-full object-cover border border-white/10 cursor-pointer"
            />
          </div>
        )}
        
        <div className="flex flex-col flex-1 min-w-0">
          <h3 className={`text-white font-medium leading-tight line-clamp-2 group-hover:text-primary transition-colors ${horizontal ? 'text-sm' : 'text-[15px]'}`}>
            {video.title}
          </h3>
          <div className="mt-1 text-sm text-muted-foreground flex flex-wrap items-center gap-1">
            <span 
              onClick={handleChannelClick} 
              className="hover:text-white cursor-pointer transition-colors"
            >
              {video.channelName}
            </span>
            <span className="text-[10px]">•</span>
            <span>{new Intl.NumberFormat('en-US', { notation: "compact" }).format(video.views || 0)} views</span>
            <span className="text-[10px]">•</span>
            <span>
              {video.publishedAt 
                ? formatDistanceToNow(new Date(video.publishedAt), { addSuffix: true })
                : 'Just now'}
            </span>
          </div>
        </div>
        
        {!horizontal && (
          <button className="self-start p-1 text-white opacity-0 group-hover:opacity-100 transition-opacity" onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}>
            <MoreVertical className="w-5 h-5" />
          </button>
        )}
      </div>
    </div>
  );
}
