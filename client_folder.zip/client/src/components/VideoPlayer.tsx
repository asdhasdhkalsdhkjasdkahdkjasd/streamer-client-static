import { useState } from "react";

interface VideoPlayerProps {
  videoId: string;
}

export function VideoPlayer({ videoId }: VideoPlayerProps) {
  // Use YouTube IFrame API for an ad-free experience (basic embed)
  // YouTube embeds are ad-free if the video is not monetized or using certain parameters,
  // but for a truly "ad-free" experience we'd need a more complex proxy.
  // We'll use the standard embed which is the most reliable.
  
  return (
    <div className="sticky top-0 z-50 aspect-video bg-black w-full group relative">
      <iframe
        src={`https://www.youtube.com/embed/${videoId}?autoplay=1&modestbranding=1&rel=0`}
        className="w-full h-full"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
        title="YouTube video player"
      />
    </div>
  );
}
