import { Link, useLocation } from "wouter";
import { Home, History } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";

export function BottomNav() {
  const [location] = useLocation();
  const { isAuthenticated } = useAuth();

  const NavItem = ({ href, icon: Icon, label }: { href: string; icon: any; label: string }) => {
    const isActive = location === href;
    return (
      <Link href={href}>
        <div className={cn(
          "flex flex-col items-center justify-center gap-1 py-2 px-4 cursor-pointer transition-colors duration-200",
          isActive ? "text-white" : "text-muted-foreground hover:text-white"
        )}>
          <Icon className={cn("w-6 h-6", isActive && "fill-current")} strokeWidth={isActive ? 2.5 : 1.5} />
          <span className="text-[10px] font-medium">{label}</span>
        </div>
      </Link>
    );
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-background/95 backdrop-blur-md border-t border-border z-50 md:hidden">
      <div className="flex justify-around items-center h-12">
        <NavItem href="/" icon={Home} label="Home" />
        <NavItem href="/history" icon={History} label="History" />
      </div>
    </div>
  );
}
