import { useState, useEffect } from "react";
import { useVideos } from "@/hooks/use-videos";
import { Link, useLocation } from "wouter";
import { Search as SearchIcon, ArrowLeft, Clock, X } from "lucide-react";
import { BottomNav } from "@/components/BottomNav";
import { formatDistanceToNow } from "date-fns";

export default function Search() {
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const { data: results, isLoading } = useVideos(debouncedQuery);
  const [, setLocation] = useLocation();

  // Simple debounce
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedQuery(query), 500);
    return () => clearTimeout(timer);
  }, [query]);

  // Mock recent searches
  const recentSearches = ["React tutorials", "Chill lofi beats", "Gaming setup 2024", "Tailwind CSS"];

  return (
    <div className="min-h-screen bg-background pb-16">
      {/* Search Header */}
      <div className="sticky top-0 z-40 bg-background px-2 py-3 border-b border-border flex items-center gap-3">
        <button onClick={() => setLocation("/")} className="p-2 hover:bg-secondary rounded-full">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div className="flex-1 relative">
          <input
            autoFocus
            type="text"
            placeholder="Search YouTube..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-secondary text-white px-4 py-2 pl-10 rounded-full focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
          <div className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none">
            <SearchIcon className="w-4 h-4 text-muted-foreground" />
          </div>
          {query && (
            <button 
              onClick={() => { setQuery(""); setDebouncedQuery(""); }}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-neutral-600 rounded-full"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
          <span className="text-xs font-bold">JD</span>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-4">
        {!debouncedQuery ? (
          <div>
            <h3 className="text-sm font-bold text-muted-foreground mb-3 px-2">Recent searches</h3>
            <div className="space-y-1">
              {recentSearches.map((term) => (
                <div 
                  key={term}
                  onClick={() => setQuery(term)}
                  className="flex items-center gap-4 p-3 hover:bg-secondary rounded-lg cursor-pointer group"
                >
                  <Clock className="w-5 h-5 text-muted-foreground group-hover:text-white" />
                  <span className="flex-1 font-medium">{term}</span>
                  <ArrowLeft className="w-4 h-4 text-muted-foreground rotate-45 opacity-0 group-hover:opacity-100" />
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {isLoading ? (
              <div className="space-y-4">
                 {[1, 2, 3].map((n) => (
                    <div key={n} className="flex gap-4 animate-pulse">
                      <div className="w-40 h-24 bg-muted rounded-xl" />
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-muted w-3/4 rounded" />
                        <div className="h-3 bg-muted w-1/2 rounded" />
                      </div>
                    </div>
                 ))}
              </div>
            ) : results?.length === 0 ? (
               <div className="text-center py-10 text-muted-foreground">No results found for "{debouncedQuery}"</div>
            ) : (
              results?.map((video) => (
                <Link key={video.id} href={`/watch/${video.id}`}>
                  <div className="flex flex-col sm:flex-row gap-4 cursor-pointer group">
                    <div className="relative w-full sm:w-64 aspect-video rounded-xl overflow-hidden bg-muted flex-shrink-0">
                      <img src={video.thumbnailUrl} alt={video.title} className="w-full h-full object-cover" />
                      <span className="absolute bottom-1 right-1 bg-black/80 text-xs px-1 rounded text-white">{video.duration}</span>
                    </div>
                    
                    <div className="flex-1 py-1">
                      <div className="flex items-start justify-between">
                         <h3 className="text-base sm:text-lg font-medium leading-tight group-hover:text-primary transition-colors line-clamp-2">{video.title}</h3>
                         <button className="p-1 opacity-0 group-hover:opacity-100"><MoreVertical className="w-4 h-4" /></button>
                      </div>
                      <div className="mt-1 text-xs sm:text-sm text-muted-foreground space-y-1">
                        <div className="flex items-center gap-1">
                          <span>{new Intl.NumberFormat('en-US', { notation: "compact" }).format(video.views || 0)} views</span>
                          <span>•</span>
                          <span>{video.publishedAt ? formatDistanceToNow(new Date(video.publishedAt), { addSuffix: true }) : ''}</span>
                        </div>
                        <div className="flex items-center gap-2 pt-2">
                          <img src={video.channelAvatar} className="w-6 h-6 rounded-full" alt="" />
                          <span className="hover:text-white transition-colors">{video.channelName}</span>
                        </div>
                        <p className="line-clamp-1 pt-1 hidden sm:block">{video.description}</p>
                      </div>
                    </div>
                  </div>
                </Link>
              ))
            )}
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}

// Icon helper needed only here
import { MoreVertical } from "lucide-react";
