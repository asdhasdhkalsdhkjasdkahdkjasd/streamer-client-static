import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { VideoCard } from "@/components/VideoCard";
import { Header } from "@/components/Header";
import { BottomNav } from "@/components/BottomNav";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Video } from "@shared/schema";

export default function Channel() {
  const [, params] = useRoute("/channel/:id");
  const channelId = params?.id;

  const { data: videos, isLoading } = useQuery<Video[]>({
    queryKey: ["/api/channels", channelId, "videos"],
    enabled: !!channelId,
  });

  // Refined shorts check
  const shorts = videos?.filter(v => {
    if (v.title.toLowerCase().includes("#shorts")) return true;
    if (!v.duration || !v.duration.startsWith('PT')) return false;
    const match = v.duration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
    if (!match) return false;
    const h = match[1] ? parseInt(match[1]) : 0;
    const m = match[2] ? parseInt(match[2]) : 0;
    const s = match[3] ? parseInt(match[3]) : 0;
    const totalSeconds = h * 3600 + m * 60 + s;
    return totalSeconds <= 60;
  });

  const regularVideos = videos?.filter(v => !shorts?.find(s => s.id === v.id));

  return (
    <div className="min-h-screen bg-background pb-16 md:pb-0">
      <Header />
      
      <main className="max-w-7xl mx-auto px-0 sm:px-4 md:px-6 lg:px-8 py-4 sm:py-6">
        <div className="px-4 mb-6">
          <h1 className="text-2xl font-bold text-white">
            {videos?.[0]?.channelName || "Channel"}
          </h1>
          <p className="text-muted-foreground text-sm">
            {videos?.length || 0} videos
          </p>
        </div>

        <Tabs defaultValue="videos" className="w-full">
          <div className="px-4 border-b border-white/10 mb-6 overflow-x-auto no-scrollbar">
            <TabsList className="bg-transparent h-auto p-0 gap-8">
              <TabsTrigger 
                value="videos" 
                className="bg-transparent data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-white rounded-none px-0 py-2 text-sm font-medium transition-none"
              >
                Videos
              </TabsTrigger>
              <TabsTrigger 
                value="shorts" 
                className="bg-transparent data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-white rounded-none px-0 py-2 text-sm font-medium transition-none"
              >
                Shorts
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="videos" className="mt-0 focus-visible:ring-0">
            {isLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-y-8 gap-x-4">
                {[1, 2, 3, 4].map((n) => (
                  <div key={n} className="flex flex-col gap-3">
                    <div className="aspect-video bg-muted rounded-xl animate-shimmer" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-y-8 gap-x-4">
                {regularVideos?.map((video) => (
                  <VideoCard key={video.id} video={video} />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="shorts" className="mt-0 focus-visible:ring-0">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-2 px-2 sm:px-0">
              {shorts?.map((video) => (
                <VideoCard key={video.id} video={video} />
              ))}
              {shorts?.length === 0 && (
                <div className="col-span-full py-12 text-center text-muted-foreground">
                  No shorts found for this channel.
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>
      
      <BottomNav />
    </div>
  );
}
