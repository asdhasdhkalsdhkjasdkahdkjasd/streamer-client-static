import { useRoute } from "wouter";
import { useVideo, useVideos } from "@/hooks/use-videos";
import { useComments, useCreateComment } from "@/hooks/use-comments";
import { VideoPlayer } from "@/components/VideoPlayer";
import { VideoCard } from "@/components/VideoCard";
import { Header } from "@/components/Header";
import { ThumbsUp, ThumbsDown, Share2, Download, ListPlus, ChevronDown, Send } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";

export default function Watch() {
  const [match, params] = useRoute("/watch/:id");
  const id = params ? parseInt(params.id) : 0;
  
  const { data: video, isLoading } = useVideo(id);
  const { data: relatedVideos } = useVideos();
  const { data: comments } = useComments(id);
  const createComment = useCreateComment();
  const { user, isAuthenticated } = useAuth();

  const [commentText, setCommentText] = useState("");
  const [isDescriptionExpanded, setIsDescriptionExpanded] = useState(false);

  // Track history when video changes
  useEffect(() => {
    if (video?.id) {
      // Create local history entry regardless of auth
      const historyItem = {
        id: video.id,
        title: video.title,
        thumbnailUrl: video.thumbnailUrl,
        channelName: video.channelName,
        duration: video.duration,
        views: video.views,
        publishedAt: video.publishedAt,
        viewedAt: new Date().toISOString()
      };
      
      const localHistory = JSON.parse(localStorage.getItem("watch_history") || "[]");
      const filteredHistory = localHistory.filter((item: any) => item.id !== video.id);
      localStorage.setItem("watch_history", JSON.stringify([historyItem, ...filteredHistory].slice(0, 50)));

      if (isAuthenticated && user?.id) {
        apiRequest("GET", `/api/videos/${video.id}`).catch(err => {
          console.error("Error updating server history:", err);
        });
      }
    }
  }, [video?.id, isAuthenticated, user?.id]);

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    createComment.mutate({ videoId: id, content: commentText });
    setCommentText("");
  };

  if (isLoading || !video) {
    return (
      <div className="min-h-screen bg-black flex flex-col">
        <div className="aspect-video w-full bg-neutral-900 animate-pulse" />
        <div className="p-4 space-y-4">
          <div className="h-6 w-3/4 bg-neutral-900 rounded animate-pulse" />
          <div className="h-4 w-1/2 bg-neutral-900 rounded animate-pulse" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-white flex flex-col lg:flex-row">
      <div className="flex-1 lg:overflow-y-auto lg:h-screen no-scrollbar">
        <Header />
        
        {/* Video Player Section */}
        <VideoPlayer videoId={video.youtubeId || ""} />

        {/* Video Info Section */}
        <div className="p-3 sm:p-4 lg:p-6 space-y-4">
          <h1 className="text-lg sm:text-xl font-bold leading-snug">{video.title}</h1>
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Link href={video.channelId ? `/channel/${video.channelId}` : '#'}>
                <img 
                  src={video.channelAvatar} 
                  alt={video.channelName}
                  className="w-10 h-10 rounded-full bg-neutral-700 cursor-pointer hover:opacity-80 transition-opacity"
                />
              </Link>
              <div className="flex flex-col">
                <Link href={video.channelId ? `/channel/${video.channelId}` : '#'}>
                  <h3 className="font-semibold text-sm sm:text-base cursor-pointer hover:text-primary transition-colors">{video.channelName}</h3>
                </Link>
                <p className="text-xs text-muted-foreground">1.2M subscribers</p>
              </div>
              <button className="ml-2 px-4 py-2 bg-white text-black rounded-full font-medium text-sm hover:bg-gray-200 transition-colors">
                Subscribe
              </button>
            </div>

            {/* Action Buttons - Scrollable on mobile */}
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-2 sm:pb-0">
              <div className="flex items-center bg-secondary rounded-full overflow-hidden">
                <button className="flex items-center gap-2 px-4 py-2 hover:bg-white/10 transition-colors border-r border-white/10">
                  <ThumbsUp className="w-5 h-5" />
                  <span className="text-sm font-medium">12K</span>
                </button>
                <button className="px-4 py-2 hover:bg-white/10 transition-colors">
                  <ThumbsDown className="w-5 h-5" />
                </button>
              </div>
              
              <button className="flex items-center gap-2 px-4 py-2 bg-secondary rounded-full hover:bg-white/10 transition-colors whitespace-nowrap">
                <Share2 className="w-5 h-5" />
                <span className="text-sm font-medium">Share</span>
              </button>
              
              <button className="flex items-center gap-2 px-4 py-2 bg-secondary rounded-full hover:bg-white/10 transition-colors whitespace-nowrap">
                <Download className="w-5 h-5" />
                <span className="text-sm font-medium">Download</span>
              </button>
            </div>
          </div>

          {/* Description Box */}
          <div 
            className="bg-secondary/50 rounded-xl p-3 cursor-pointer hover:bg-secondary/70 transition-colors"
            onClick={() => setIsDescriptionExpanded(!isDescriptionExpanded)}
          >
            <div className="flex gap-2 text-sm font-bold mb-1">
              <span>{new Intl.NumberFormat('en-US', { notation: "compact" }).format(video.views || 0)} views</span>
              <span>{formatDistanceToNow(new Date(video.publishedAt!), { addSuffix: true })}</span>
            </div>
            <p className={`text-sm text-white/90 whitespace-pre-wrap ${!isDescriptionExpanded && 'line-clamp-2'}`}>
              {video.description}
            </p>
            {!isDescriptionExpanded && (
              <span className="text-sm font-medium mt-1 block">...more</span>
            )}
          </div>

          {/* Comments Preview */}
          <div className="mt-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-lg">Comments <span className="text-muted-foreground font-normal ml-1">{comments?.length || 0}</span></h3>
              <ChevronDown className="w-5 h-5" />
            </div>

            {/* Add Comment Input */}
            <form onSubmit={handleCommentSubmit} className="flex gap-3 mb-6">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-500 to-pink-500 flex items-center justify-center text-[10px] font-bold">ME</div>
              <div className="flex-1 relative">
                <input 
                  type="text" 
                  placeholder="Add a comment..." 
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="w-full bg-transparent border-b border-white/20 py-1.5 px-0 text-sm focus:outline-none focus:border-white transition-colors"
                />
                {commentText && (
                  <button 
                    type="submit" 
                    disabled={createComment.isPending}
                    className="absolute right-0 bottom-2 text-primary hover:text-primary/80 disabled:opacity-50"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                )}
              </div>
            </form>

            {/* Comment List */}
            <div className="space-y-4">
              {comments?.map((comment) => (
                <div key={comment.id} className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-neutral-700 flex-shrink-0 overflow-hidden">
                    <img src={comment.avatar} alt={comment.username} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium text-white/90">@{comment.username}</span>
                      <span className="text-[10px] text-muted-foreground">
                        {comment.createdAt && formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                      </span>
                    </div>
                    <p className="text-sm leading-relaxed">{comment.content}</p>
                    <div className="flex items-center gap-4 mt-1">
                      <button className="flex items-center gap-1 text-xs text-white/70 hover:text-white">
                        <ThumbsUp className="w-3.5 h-3.5" />
                        <span>{comment.likes}</span>
                      </button>
                      <button className="text-white/70 hover:text-white">
                        <ThumbsDown className="w-3.5 h-3.5" />
                      </button>
                      <button className="text-xs font-medium text-white/70 hover:text-white">Reply</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Recommended Videos (Sidebar on Desktop, Bottom on Mobile) */}
      <div className="lg:w-[400px] lg:h-screen lg:overflow-y-auto lg:border-l border-white/10 p-4 bg-background">
        <h3 className="font-bold text-lg mb-4 hidden lg:block">Up Next</h3>
        <div className="flex flex-col gap-4">
          {relatedVideos?.filter(v => v.id !== id).map(video => (
            <Link key={video.id} href={`/watch/${video.id}`}>
              <div className="flex gap-2 cursor-pointer group">
                <div className="relative w-40 aspect-video rounded-lg overflow-hidden bg-muted flex-shrink-0">
                  <img src={video.thumbnailUrl} className="w-full h-full object-cover" alt="" />
                  <span className="absolute bottom-1 right-1 bg-black/80 text-[10px] px-1 rounded text-white">{video.duration}</span>
                </div>
                <div className="flex flex-col gap-1 min-w-0">
                  <h4 className="text-sm font-medium line-clamp-2 leading-tight group-hover:text-primary transition-colors">{video.title}</h4>
                  <div className="text-xs text-muted-foreground">
                    <p>{video.channelName}</p>
                    <p>{new Intl.NumberFormat('en-US', { notation: "compact" }).format(video.views || 0)} views • {formatDistanceToNow(new Date(video.publishedAt!), { addSuffix: true })}</p>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
