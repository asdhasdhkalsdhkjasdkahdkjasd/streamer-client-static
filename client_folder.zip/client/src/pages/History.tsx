import { useQuery } from "@tanstack/react-query";
import { VideoCard } from "@/components/VideoCard";
import { BottomNav } from "@/components/BottomNav";
import { Header } from "@/components/Header";
import { Video } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { useState, useEffect } from "react";
import { Search, X } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function HistoryPage() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  
  // Use local history as the primary source for consistency
  const [localHistory, setLocalHistory] = useState<Video[]>([]);
  
  useEffect(() => {
    const history = JSON.parse(localStorage.getItem("watch_history") || "[]");
    setLocalHistory(history);
  }, []);

  const { data: serverHistory, isLoading: isServerLoading } = useQuery<Video[]>({
    queryKey: ["/api/history", user?.id],
    queryFn: async () => {
      const response = await fetch("/api/history");
      if (!response.ok) return [];
      return response.json();
    },
    enabled: !!user?.id && isAuthenticated && !authLoading,
    retry: false,
  });

  if (authLoading) return null;

  // Merge local and server history if authenticated, otherwise just show local
  const baseVideos = isAuthenticated ? (serverHistory?.length ? serverHistory : localHistory) : localHistory;
  
  // Filter based on search term
  const displayVideos = baseVideos.filter(video => 
    video.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    video.channelName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const isLoading = isAuthenticated ? isServerLoading : false;

  return (
    <div className="min-h-screen bg-background pb-16 md:pb-0">
      <Header />
      
      <main className="max-w-7xl mx-auto px-0 sm:px-4 md:px-6 lg:px-8 py-4 sm:py-6">
        <div className="px-4 mb-6">
          <h1 className="text-2xl font-bold mb-4">History</h1>
          
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search watch history"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-10 bg-secondary/50 border-none focus-visible:ring-1 focus-visible:ring-primary h-10 rounded-full"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-white/10 rounded-full"
              >
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            )}
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-y-8 gap-x-4">
            {[1, 2, 3, 4].map((n) => (
              <div key={n} className="flex flex-col gap-3">
                <div className="aspect-video bg-muted rounded-xl animate-pulse" />
                <div className="flex gap-3">
                  <div className="w-9 h-9 rounded-full bg-muted flex-shrink-0 animate-pulse" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-muted rounded w-3/4 animate-pulse" />
                    <div className="h-3 bg-muted rounded w-1/2 animate-pulse" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : displayVideos?.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center px-4">
            <h2 className="text-xl font-semibold mb-2">No watch history yet</h2>
            <p className="text-muted-foreground">Videos you watch will show up here.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-y-8 gap-x-4">
            {displayVideos?.map((video) => (
              <VideoCard key={video.id} video={video as any} />
            ))}
          </div>
        )}
      </main>
      
      <BottomNav />
    </div>
  );
}