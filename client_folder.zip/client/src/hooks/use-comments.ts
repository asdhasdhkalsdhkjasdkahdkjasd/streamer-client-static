import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { Comment } from "@shared/schema";

// GET /api/videos/:videoId/comments
export function useComments(videoId: number) {
  return useQuery({
    queryKey: [api.comments.list.path, videoId],
    queryFn: async () => {
      const url = buildUrl(api.comments.list.path, { videoId });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch comments");
      return api.comments.list.responses[200].parse(await res.json());
    },
    enabled: !isNaN(videoId),
  });
}

// POST /api/comments
export function useCreateComment() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ videoId, content }: { videoId: number; content: string }) => {
      const validatedInput = api.comments.create.input.parse({ videoId, content });
      
      const res = await fetch(api.comments.create.path, {
        method: api.comments.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validatedInput),
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.comments.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to post comment");
      }
      return api.comments.create.responses[201].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      const url = buildUrl(api.comments.list.path, { videoId: variables.videoId });
      queryClient.invalidateQueries({ queryKey: [api.comments.list.path, variables.videoId] });
    },
  });
}
