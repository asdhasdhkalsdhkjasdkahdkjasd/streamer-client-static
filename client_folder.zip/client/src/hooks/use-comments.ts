import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { Comment } from "@shared/schema";

// GET /api/videos/:videoId/comments
export function useComments(videoId: number) {
  return useQuery({
    queryKey: [api.comments.list.path, videoId],
    queryFn: async () => {
      // Attempt to fetch comments from the API. If this static site
      // is running without a backend the request will fail. In that
      // case we fall back to an empty comment list instead of throwing
      // an error so the UI can still render.
      try {
        const url = buildUrl(api.comments.list.path, { videoId });
        const res = await fetch(url);
        if (!res.ok) throw new Error("Failed to fetch comments");
        return api.comments.list.responses[200].parse(await res.json());
      } catch (err) {
        return [] as Comment[];
      }
    },
    enabled: !isNaN(videoId),
  });
}

// POST /api/comments
export function useCreateComment() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ videoId, content }: { videoId: number; content: string }) => {
      // When running as a static site there is no backend to persist
      // comments. We still allow users to submit comments by storing
      // them in localStorage keyed by the video ID. This provides a
      // functional experience offline. The API input parser is still
      // used to validate the payload shape.
      const validatedInput = api.comments.create.input.parse({ videoId, content });
      // Try to post to the API. If it fails we will fall back to
      // localStorage below.
      try {
        const res = await fetch(api.comments.create.path, {
          method: api.comments.create.method,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(validatedInput),
        });
        if (!res.ok) {
          if (res.status === 400) {
            const error = api.comments.create.responses[400].parse(await res.json());
            throw new Error(error.message);
          }
          throw new Error("Failed to post comment");
        }
        return api.comments.create.responses[201].parse(await res.json());
      } catch (err) {
        // Fallback: persist the comment locally. Generate a simple
        // numeric ID using the current timestamp.
        const newComment: Comment = {
          id: Date.now(),
          videoId,
          content: validatedInput.content,
          // Provide a minimal user object. When offline there is no
          // authentication so we mark the comment as coming from a guest.
          user: {
            id: 0,
            name: "Guest",
            avatarUrl: "",
          },
          createdAt: new Date().toISOString(),
        };
        const key = `comments_${videoId}`;
        const existing = localStorage.getItem(key);
        const list: Comment[] = existing ? JSON.parse(existing) : [];
        list.push(newComment);
        localStorage.setItem(key, JSON.stringify(list));
        return newComment;
      }
    },
    onSuccess: (data, variables) => {
      // After creating a comment (either via API or locally) update the
      // query cache so the new comment appears in the UI immediately.
      queryClient.setQueryData([api.comments.list.path, variables.videoId], (old) => {
        if (Array.isArray(old)) {
          return [...old, data] as Comment[];
        }
        return [data] as Comment[];
      });
    },
  });
}
