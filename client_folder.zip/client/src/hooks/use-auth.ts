import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { User } from "@shared/models/auth";

async function fetchUser(): Promise<User | null> {
  try {
    const response = await fetch("/api/auth/user", {
      credentials: "include",
    });

    // If the user is not authenticated, return null. In a static build
    // this endpoint may not exist, so fallback to null on a 404 as well.
    if (response.status === 401 || response.status === 404) {
      return null;
    }

    if (!response.ok) {
      // Throw an error for other HTTP errors to be caught below.
      throw new Error(`${response.status}: ${response.statusText}`);
    }

    return response.json();
  } catch (err) {
    // In offline/static mode, fetching the user will likely fail because the
    // backend does not exist. Swallow errors and treat the user as unauthenticated.
    return null;
  }
}

async function logout(): Promise<void> {
  window.location.href = "/api/logout";
}

export function useAuth() {
  const queryClient = useQueryClient();
  const { data: user, isLoading } = useQuery<User | null>({
    queryKey: ["/api/auth/user"],
    queryFn: fetchUser,
    retry: false,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  const logoutMutation = useMutation({
    mutationFn: logout,
    onSuccess: () => {
      queryClient.setQueryData(["/api/auth/user"], null);
    },
  });

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    logout: logoutMutation.mutate,
    isLoggingOut: logoutMutation.isPending,
  };
}
