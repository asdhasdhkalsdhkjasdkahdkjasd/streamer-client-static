import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertVideo, type Video } from "@shared/schema";

// GET /api/videos
/**
 * Fetches a list of videos.
 *
 * In the original full‑stack application this would hit `/api/videos` on the server.
 * When running the client as a static site (e.g. on Netlify without a backend), the
 * API endpoints are unavailable and will throw an error. To ensure the UI still
 * functions offline, we attempt to fetch from the API first and fall back to
 * loading a local JSON file (`/videos.json`) bundled in the public folder. If a
 * search term is provided the list is filtered client‑side by title,
 * description or channel name.
 */
export function useVideos(search?: string) {
  return useQuery({
    queryKey: [api.videos.list.path, search],
    queryFn: async () => {
      const url = search
        ? `${api.videos.list.path}?search=${encodeURIComponent(search)}`
        : api.videos.list.path;
      // Try to fetch from the API. If it fails (e.g. running without a server)
      // then fall back to a static JSON file.
      try {
        const res = await fetch(url);
        if (res.ok) {
          // Use the schema parser to validate and coerce the server response.
          return api.videos.list.responses[200].parse(await res.json());
        }
        // If the response is not ok, throw to trigger the catch below.
        throw new Error(`API response status ${res.status}`);
      } catch (err) {
        // Fallback: load the bundled videos.json. This file lives under
        // `client/public/videos.json` and is copied to the root of the built site.
        const fallbackRes = await fetch("/videos.json");
        if (!fallbackRes.ok) {
          throw new Error("Failed to fetch videos");
        }
        let data = (await fallbackRes.json()) as Video[];
        // If a search term is provided, filter the list client‑side. The
        // comparison is case‑insensitive and matches title, description or
        // channelName.
        if (search) {
          const query = search.toLowerCase();
          data = data.filter((v) => {
            return (
              v.title.toLowerCase().includes(query) ||
              v.description.toLowerCase().includes(query) ||
              v.channelName.toLowerCase().includes(query)
            );
          });
        }
        return data;
      }
    },
  });
}

// GET /api/videos/:id
export function useVideo(id: number) {
  return useQuery({
    queryKey: [api.videos.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.videos.get.path, { id });
      // Attempt to fetch the video from the API. If that fails (e.g. static site)
      // fall back to the local videos.json and look up the video by its ID.
      try {
        const res = await fetch(url);
        if (res.status === 404) throw new Error("Video not found");
        if (!res.ok) throw new Error("Failed to fetch video");
        return api.videos.get.responses[200].parse(await res.json());
      } catch (err) {
        // Fallback: fetch the entire list and pick the correct video by ID.
        const fallbackRes = await fetch("/videos.json");
        if (!fallbackRes.ok) {
          throw new Error("Failed to fetch video");
        }
        const data = (await fallbackRes.json()) as Video[];
        const video = data.find((v) => v.id === id);
        if (!video) {
          throw new Error("Video not found");
        }
        return video;
      }
    },
    enabled: !isNaN(id),
  });
}
