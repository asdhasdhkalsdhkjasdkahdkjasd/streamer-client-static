import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertVideo, type Video } from "@shared/schema";

// GET /api/videos
export function useVideos(search?: string) {
  return useQuery({
    queryKey: [api.videos.list.path, search],
    queryFn: async () => {
      const url = search 
        ? `${api.videos.list.path}?search=${encodeURIComponent(search)}`
        : api.videos.list.path;
      
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch videos");
      return api.videos.list.responses[200].parse(await res.json());
    },
  });
}

// GET /api/videos/:id
export function useVideo(id: number) {
  return useQuery({
    queryKey: [api.videos.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.videos.get.path, { id });
      const res = await fetch(url);
      if (res.status === 404) throw new Error("Video not found");
      if (!res.ok) throw new Error("Failed to fetch video");
      return api.videos.get.responses[200].parse(await res.json());
    },
    enabled: !isNaN(id),
  });
}
