import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertVideo, type Video } from "@shared/schema";

// Helper to convert YouTube API responses into our internal Video type.
// When details are split between search and videos endpoints we pass both
// objects. The index is used to generate a stable numeric ID.
function mapToVideo(searchItem: any, detailItem: any, index: number): Video {
  const snippet = detailItem?.snippet || searchItem?.snippet || {};
  const statistics = detailItem?.statistics || {};
  const contentDetails = detailItem?.contentDetails || {};
  const videoId = detailItem?.id || searchItem?.id?.videoId || searchItem?.id;
  return {
    id: index + 1,
    youtubeId: videoId || "",
    title: snippet.title || "",
    description: snippet.description || "",
    thumbnailUrl:
      snippet?.thumbnails?.high?.url ||
      snippet?.thumbnails?.medium?.url ||
      snippet?.thumbnails?.default?.url ||
      "",
    channelName: snippet.channelTitle || "",
    channelId: snippet.channelId || "",
    channelAvatar: "", // will be filled later when channel info is fetched
    views: statistics.viewCount ? parseInt(statistics.viewCount, 10) : 0,
    duration: contentDetails?.duration || "",
    publishedAt: snippet.publishedAt || undefined,
  } as Video;
}

// GET /api/videos
/**
 * Fetches a list of videos.
 *
 * In the original full‑stack application this would hit `/api/videos` on the server.
 * When running the client as a static site (e.g. on Netlify without a backend), the
 * API endpoints are unavailable and will throw an error. To ensure the UI still
 * functions offline, we attempt to fetch from the API first and fall back to
 * loading a local JSON file (`/videos.json`) bundled in the public folder. If a
 * search term is provided the list is filtered client‑side by title,
 * description or channel name.
 */
export function useVideos(search?: string) {
  const queryClient = useQueryClient();
  return useQuery({
    queryKey: ["youtubeVideos", search],
    queryFn: async () => {
      const apiKey = (import.meta as any).env?.VITE_YOUTUBE_API_KEY;
      // If an API key is provided, attempt to fetch from YouTube. Otherwise fall back.
      if (apiKey) {
        try {
          // When a search term is provided we need to call the search endpoint first
          // then fetch full details for each video. Otherwise we call the videos
          // endpoint directly to get trending/most popular videos.
          let videos: Video[] = [];
          if (search) {
            const searchUrl =
              `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=20&q=${encodeURIComponent(
                search,
              )}&key=${apiKey}`;
            const searchRes = await fetch(searchUrl);
            if (!searchRes.ok) throw new Error(`Search API error ${searchRes.status}`);
            const searchData = await searchRes.json();
            const ids: string = searchData.items
              .map((item: any) => item.id.videoId)
              .filter(Boolean)
              .join(",");
            // Fetch details for these video IDs
            const detailsUrl =
              `https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics,contentDetails&id=${ids}&key=${apiKey}`;
            const detailsRes = await fetch(detailsUrl);
            if (!detailsRes.ok) throw new Error(`Videos API error ${detailsRes.status}`);
            const detailsData = await detailsRes.json();
            const detailsById: Record<string, any> = {};
            detailsData.items.forEach((item: any) => {
              detailsById[item.id] = item;
            });
            videos = searchData.items.map((item: any, idx: number) => {
              const detail = detailsById[item.id.videoId];
              return mapToVideo(item, detail, idx);
            });
          } else {
            // Fetch most popular videos (region default is US)
            const videosUrl =
              `https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics,contentDetails&chart=mostPopular&maxResults=20&regionCode=US&key=${apiKey}`;
            const res = await fetch(videosUrl);
            if (!res.ok) throw new Error(`Videos API error ${res.status}`);
            const data = await res.json();
            videos = data.items.map((item: any, idx: number) => {
              return mapToVideo(item, item, idx);
            });
          }
          // Fetch channel avatars in a separate call
          const channelIds = Array.from(
            new Set(videos.map((v) => v.channelId).filter(Boolean)),
          ).join(",");
          if (channelIds) {
            const channelsUrl =
              `https://www.googleapis.com/youtube/v3/channels?part=snippet&id=${channelIds}&key=${apiKey}`;
            const channelsRes = await fetch(channelsUrl);
            if (channelsRes.ok) {
              const channelsData = await channelsRes.json();
              const channelAvatarById: Record<string, string> = {};
              channelsData.items.forEach((ch: any) => {
                const thumb =
                  ch.snippet?.thumbnails?.high?.url ||
                  ch.snippet?.thumbnails?.medium?.url ||
                  ch.snippet?.thumbnails?.default?.url ||
                  "";
                channelAvatarById[ch.id] = thumb;
              });
              videos = videos.map((v) => {
                return { ...v, channelAvatar: channelAvatarById[v.channelId] || v.channelAvatar };
              });
            }
          }
          // Cache the videos list so that useVideo can retrieve individual entries
          queryClient.setQueryData(["youtubeVideos", "list"], videos);
          return videos;
        } catch (err) {
          console.error("YouTube fetch error", err);
          // Fall through to local data below
        }
      }
      // Fallback: attempt to fetch from the original API
      const url = search
        ? `${api.videos.list.path}?search=${encodeURIComponent(search)}`
        : api.videos.list.path;
      try {
        const res = await fetch(url);
        if (res.ok) {
          return api.videos.list.responses[200].parse(await res.json());
        }
        throw new Error(`API response status ${res.status}`);
      } catch (err) {
        // Fallback to bundled static JSON
        const fallbackRes = await fetch("/videos.json");
        if (!fallbackRes.ok) {
          throw new Error("Failed to fetch videos");
        }
        let data = (await fallbackRes.json()) as Video[];
        if (search) {
          const query = search.toLowerCase();
          data = data.filter((v) => {
            return (
              v.title.toLowerCase().includes(query) ||
              v.description.toLowerCase().includes(query) ||
              v.channelName.toLowerCase().includes(query)
            );
          });
        }
        return data;
      }
    },
  });
}

// GET /api/videos/:id
export function useVideo(id: number) {
  const queryClient = useQueryClient();
  return useQuery({
    // Use a different key when fetching individual videos. This ensures separate caching
    // and allows us to look up videos from the YouTube list cache when available.
    queryKey: ["youtubeVideo", id],
    queryFn: async () => {
      // First attempt: see if we already have a list of YouTube videos cached from
      // useVideos. This is keyed under ["youtubeVideos", "list"]. If a matching
      // video is found by its numeric ID, return it immediately.
      const cachedList = queryClient.getQueryData<Video[]>(["youtubeVideos", "list"]);
      if (cachedList && !isNaN(id)) {
        const cachedVideo = cachedList.find((v) => v.id === id);
        if (cachedVideo) {
          return cachedVideo;
        }
      }
      // Next attempt: try to fetch from the API if the server is running. If that
      // fails (e.g. when deployed as a static site), fall back to the local
      // videos.json file.
      const url = buildUrl(api.videos.get.path, { id });
      try {
        const res = await fetch(url);
        if (res.status === 404) throw new Error("Video not found");
        if (!res.ok) throw new Error("Failed to fetch video");
        return api.videos.get.responses[200].parse(await res.json());
      } catch (err) {
        // Fallback: fetch the entire list and pick the correct video by ID. If
        // videos.json cannot be loaded or the ID does not exist, throw.
        const fallbackRes = await fetch("/videos.json");
        if (!fallbackRes.ok) {
          throw new Error("Failed to fetch video");
        }
        const data = (await fallbackRes.json()) as Video[];
        const video = data.find((v) => v.id === id);
        if (!video) {
          throw new Error("Video not found");
        }
        return video;
      }
    },
    enabled: !isNaN(id),
  });
}
