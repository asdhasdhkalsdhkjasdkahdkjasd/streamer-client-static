import { pgTable, text, serial, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  youtubeId: text("youtube_id").notNull().unique(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  thumbnailUrl: text("thumbnail_url").notNull(),
  channelName: text("channel_name").notNull(),
  channelId: text("channel_id"),
  channelAvatar: text("channel_avatar").notNull(),
  views: integer("views").default(0),
  duration: text("duration").notNull(), // Format "MM:SS"
  publishedAt: timestamp("published_at").defaultNow(),
});

export const videoHistory = pgTable("video_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  videoId: integer("video_id").notNull(),
  viewedAt: timestamp("viewed_at").defaultNow(),
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id").notNull(),
  username: text("username").notNull(),
  avatar: text("avatar").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  likes: integer("likes").default(0),
});

export const insertVideoSchema = createInsertSchema(videos).omit({ id: true, publishedAt: true, views: true });
export const insertCommentSchema = createInsertSchema(comments).omit({ id: true, createdAt: true, likes: true });

export * from "./models/auth";

export type Video = typeof videos.$inferSelect;
export type InsertVideo = z.infer<typeof insertVideoSchema>;
export type Comment = typeof comments.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;

export type CreateCommentRequest = {
  videoId: number;
  content: string;
};
